package UserLogin.view;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Objects;
import java.util.Scanner;

import UserLogin.LoginMain;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class UserLoginViewController {
	
	@FXML
	public Button closeButton;
	@FXML
	public ChoiceBox<String> userTypeBox;
	@FXML
	public TextField userNameField;
	@FXML
	public PasswordField passwordField;
	
	public String fileName = null;
	
	ObservableList<String> userTypeList = FXCollections.observableArrayList("Customer", "Supplier");
	
	private LoginMain main;
	
	@FXML
	private void initialize()
	{
		userTypeBox.setValue("Customer");
		userTypeBox.setItems(userTypeList);
	}
	
	@FXML
	private void goCreateAccount() throws IOException
	{
		main.showCreateAccountScene();
	}
	
	@FXML
	public void loginCheck() throws IOException
	{	
		String userName = userNameField.getText();
		String password = passwordField.getText();
		String userType = userTypeBox.getValue().toString();
		
		if(Objects.equals(userType, "Customer"))
		{
			fileName = "C:/Users/Christian/eclipse-workspace/LoginSystem/src/UserInfo.txt";
		}
		else if(Objects.equals(userType, "Supplier"))
		{
			fileName = "C:/Users/Christian/eclipse-workspace/LoginSystem/src/SupplierLogin.txt";
		}
		
		File file2 = new File("C:/Users/Christian/eclipse-workspace/LoginSystem/src/LoginSave.txt");
		File file = new File(fileName);
		Scanner scanner = new Scanner(file);
		Scanner loginScanner = new Scanner(file2);
		FileWriter fileWriter = new FileWriter(file2, true);
		PrintWriter printWriter = new PrintWriter(fileWriter);
		
		boolean check = true;
		
		while(scanner.hasNextLine())
		{
			String line = scanner.nextLine();
			if(Objects.equals(userName, line))
			{
				if(Objects.equals(password, scanner.nextLine()) && Objects.equals(userName, line))
				{
					printWriter.println(userName);
					printWriter.println("");
					printWriter.close();
					if(Objects.equals(userType, "Customer"))
					{
						main.showCustomerViewScene();
					}
					else if(Objects.equals(userType, "Supplier"))
					{
						main.showSupplierViewScene();
					}
					check = false;
					break;
				}
				else
				{
					main.showWrongPasswordScene();
					break;
				}
			}
			
		}
		
		if(check)
		{
			main.showUsernameNotFoundScene();
		}
	}
	
	public void closeWindow() throws IOException
	{
		Stage stage = (Stage) closeButton.getScene().getWindow();
		stage.close();
	}

}
