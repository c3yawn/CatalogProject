package UserLogin.view;

import UserLogin.LoginMain;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class FinalSceneController {
	
	private LoginMain main;
	
	@FXML
	public Button okButton;
	
	public void okButton()
	{
		okButton.getScene().getWindow().hide();
	}
}
