package UserLogin.view;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Objects;
import java.util.Scanner;

import UserLogin.LoginMain;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class SupplierViewOrderContoller {
	
	private LoginMain main;
	
	@FXML
	public Button processButton;
	@FXML
	public Button logoutButton;
	@FXML
	public Button okButton;
	@FXML
	public Label iPhoneLabel;
	@FXML
	public Label galaxyLabel;
	@FXML
	public Label pixelLabel;
	@FXML
	public Label pixelXLLabel;
	@FXML
	public Label onePlusLabel;
	
	public String iPhoneTotal;
	public String galaxyTotal;
	public String pixel3Total;
	public String pixelXLTotal;
	public String onePlusTotal;
	
	public void getLabel() throws FileNotFoundException
	{	
		File file = new File("C:/Users/Christian/eclipse-workspace/LoginSystem/src/DeliveryOrder.txt");
		Scanner iPhoneScanner = new Scanner(file);
		Scanner galaxyScanner = new Scanner(file);
		Scanner pixel3Scanner = new Scanner(file);
		Scanner pixelXLScanner = new Scanner(file);
		Scanner onePlusScanner = new Scanner(file);
		
		int iPhoneTemp = 0;
		int galaxyTemp = 0;
		int pixel3Temp = 0;
		int pixelXLTemp = 0;
		int onePlusTemp = 0;
		
		while(iPhoneScanner.hasNextLine())
		{
			String line = iPhoneScanner.nextLine();
			if(Objects.equals("iPhone X", line))
			{
				iPhoneTemp += Integer.parseInt(iPhoneScanner.nextLine());
			}
		}
		iPhoneTotal = Integer.toString(iPhoneTemp);
		
		while(galaxyScanner.hasNextLine())
		{
			String line = galaxyScanner.nextLine();
			if(Objects.equals("Galaxy S10+", line))
			{
				galaxyTemp += Integer.parseInt(galaxyScanner.nextLine());
			}
		}
		galaxyTotal = Integer.toString(galaxyTemp);
		
		while(pixel3Scanner.hasNextLine())
		{
			String line = pixel3Scanner.nextLine();
			if(Objects.equals("Pixel 3", line))
			{
				pixel3Temp += Integer.parseInt(pixel3Scanner.nextLine());
			}
		}
		pixel3Total = Integer.toString(pixel3Temp);
		
		while(pixelXLScanner.hasNextLine())
		{
			String line = pixelXLScanner.nextLine();
			if(Objects.equals("Pixel 3 XL", line))
			{
				pixelXLTemp += Integer.parseInt(pixelXLScanner.nextLine());
			}
		}
		pixelXLTotal = Integer.toString(pixelXLTemp);
		
		while(onePlusScanner.hasNextLine())
		{
			String line = onePlusScanner.nextLine();
			if(Objects.equals("OnePlus 6T", line))
			{
				onePlusTemp += Integer.parseInt(onePlusScanner.nextLine());
			}
		}
		onePlusTotal = Integer.toString(onePlusTemp);
		
		iPhoneScanner.close();
		galaxyScanner.close();
		pixel3Scanner.close();
		pixelXLScanner.close();
		onePlusScanner.close();
	}
	
	@FXML
	private void initialize() throws FileNotFoundException
	{
		getLabel();
		iPhoneLabel.setText(iPhoneTotal);
		galaxyLabel.setText(galaxyTotal);
		pixelLabel.setText(pixel3Total);
		pixelXLLabel.setText(pixelXLTotal);
		onePlusLabel.setText(onePlusTotal);
	}
	
	public void closeWindow() throws IOException
	{
		FileWriter fw = new FileWriter("C:/Users/Christian/eclipse-workspace/LoginSystem/src/LoginSave.txt",false);
		fw.write("");
		fw.close();
		Stage stage = (Stage) logoutButton.getScene().getWindow();
		stage.close();
	}
	
	public void okButton() throws IOException
	{
		okButton.getScene().getWindow().hide();
		main.showSupplierViewScene();
	}
	
	@FXML
	public void processOrder() throws IOException
	{
		String Order_list[] = new String[10];
		String Inventory_list[] = new String[10];
		boolean[] Inventory_Order = new boolean[5];
		
		Order_list[0] = "iPhone 10";
		Order_list[1] = iPhoneTotal;
		Order_list[2] = "Galaxy S10+";
		Order_list[3] = galaxyTotal;
		Order_list[4] = "Pixel 3";
		Order_list[5] = pixel3Total;
		Order_list[6] = "Pixel 3 XL";
		Order_list[7] = pixelXLTotal;
		Order_list[8] = "OnePlus 6T";
		Order_list[9] = "0";
		
		Inventory_list[0] = "iPhone 10";
		Inventory_list[1] = "20";
		Inventory_list[2] = "Galaxy S10+";
		Inventory_list[3] = "12";
		Inventory_list[4] = "Pixel 3";
		Inventory_list[5] = "1";
		Inventory_list[6] = "Pixel 3 XL";
		Inventory_list[7] = "25";
		Inventory_list[8] = "OnePlus 6T";
		Inventory_list[9] = "16";
		
		int iPhoneNeeded = 0;
		int galaxyNeeded = 0;
		int pixelNeeded = 0;
		int pixelXLNeeded = 0;
		int onePlusNeeded = 0;
		
		File file = new File("C:/Users/Christian/eclipse-workspace/LoginSystem/src/BooleanCheck.txt");
		FileWriter fw = new FileWriter(file, false);
		PrintWriter pw = new PrintWriter(fw);
		
		if(Integer.parseInt(Inventory_list[1]) < Integer.parseInt(iPhoneTotal))
		{
			pw.println("false");
			iPhoneNeeded = Integer.parseInt(iPhoneTotal) - Integer.parseInt(Inventory_list[1]);
			Integer.toString(iPhoneNeeded);
			pw.println(iPhoneNeeded);
		}
		else
		{
			pw.println("true");
			pw.println("0");
		}
		
		if(Integer.parseInt(Inventory_list[3]) < Integer.parseInt(galaxyTotal))
		{
			pw.println("false");
			galaxyNeeded = Integer.parseInt(galaxyTotal) - Integer.parseInt(Inventory_list[3]);
			Integer.toString(galaxyNeeded);
			pw.println(galaxyNeeded);
		}
		else
		{
			pw.println("true");
			pw.println("0");
		}
		
		if(Integer.parseInt(Inventory_list[5]) < Integer.parseInt(pixel3Total))
		{
			pw.println("false");
			pixelNeeded = Integer.parseInt(pixel3Total) - Integer.parseInt(Inventory_list[5]);
			Integer.toString(pixelNeeded);
			pw.println(pixelNeeded);
		}
		else
		{
			pw.println("true");
			pw.println("0");
		}
		
		if(Integer.parseInt(Inventory_list[7]) < Integer.parseInt(pixelXLTotal))
		{
			pw.println("false");
			pixelXLNeeded = Integer.parseInt(pixelXLTotal) - Integer.parseInt(Inventory_list[7]);
			Integer.toString(pixelXLNeeded);
			pw.println(pixelXLNeeded);
		}
		else
		{
			pw.println("true");
			pw.println("0");
		}
		
		if(Integer.parseInt(Inventory_list[9]) < Integer.parseInt(onePlusTotal))
		{
			pw.println("false");
			onePlusNeeded = Integer.parseInt(onePlusTotal) - Integer.parseInt(Inventory_list[9]);
			Integer.toString(onePlusNeeded);
			pw.println(onePlusNeeded);
		}
		else
		{
			pw.println("true");
			pw.println("0");
		}
		pw.close();
		processButton.getScene().getWindow().hide();
		main.showOrderProcessScene();
	}
	
}
