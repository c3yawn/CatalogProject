package UserLogin.view;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import UserLogin.LoginMain;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class OrderProcessController {

	private LoginMain main;
	
	@FXML
	public Label iPhoneLabel;
	@FXML
	public Label galaxyLabel;
	@FXML
	public Label pixel3Label;
	@FXML
	public Label pixelXLLabel;
	@FXML
	public Label onePlusLabel;
	@FXML
	public Button processButton;
	
	@FXML
	private void initialize() throws IOException
	{
		File file = new File("C:/Users/Christian/eclipse-workspace/LoginSystem/src/BooleanCheck.txt");
		Scanner scanner = new Scanner(file);
		
		String line = scanner.nextLine();
		if(line.equals("false"))
		{
			iPhoneLabel.setText("Inventory Needed");
		}
		else
		{
			iPhoneLabel.setText("Inventory Sufficient");
		}
		
		scanner.nextLine();
		line = scanner.nextLine();
		if(line.equals("false"))
		{
			galaxyLabel.setText("Inventory Needed");
		}
		else
		{
			galaxyLabel.setText("Inventory Sufficient");
		}
		
		scanner.nextLine();
		line = scanner.nextLine();
		if(line.equals("false"))
		{
			pixel3Label.setText("Inventory Needed");
		}
		else
		{
			pixel3Label.setText("Inventory Sufficient");
		}
		
		scanner.nextLine();
		line = scanner.nextLine();
		if(line.equals("false"))
		{
			pixelXLLabel.setText("Inventory Needed");
		}
		else
		{
			pixelXLLabel.setText("Inventory Sufficient");
		}
		
		scanner.nextLine();
		line = scanner.nextLine();
		if(line.equals("false"))
		{
			onePlusLabel.setText("Inventory Needed");
		}
		else
		{
			onePlusLabel.setText("Inventory Sufficient");
		}
	}
	
	public void processOrderButton() throws IOException
	{
		iPhoneLabel.getScene().getWindow().hide();
		main.showInventoryOrderScene();
	}
	
}
