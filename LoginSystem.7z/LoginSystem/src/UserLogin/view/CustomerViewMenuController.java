package UserLogin.view;

import java.io.FileWriter;
import java.io.IOException;

import UserLogin.LoginMain;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class CustomerViewMenuController {
	
	private LoginMain main;

	@FXML
	public Button logoutButton;
	@FXML
	public Button viewOrderButton;
	@FXML
	public Button viewCatalogButton;
	
	public void goViewCatalog() throws IOException
	{
		viewCatalogButton.getScene().getWindow().hide();
		main.showCatalogScene();
	}
	
	public void goLogout() throws IOException
	{
		FileWriter fw = new FileWriter("C:/Users/Christian/eclipse-workspace/LoginSystem/src/LoginSave.txt",false);
		fw.write("");
		fw.close();
		Stage stage = (Stage) logoutButton.getScene().getWindow();
		stage.close();
	}
	
	public void goViewOrder() throws IOException
	{
		viewCatalogButton.getScene().getWindow().hide();
		main.showViewOrderScene();
	}
	
}
