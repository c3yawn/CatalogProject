package UserLogin.view;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Objects;
import java.util.Scanner;

import UserLogin.LoginMain;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class CustomerViewOrderController {
	
	private LoginMain main;
	
	@FXML
	public Button okButton;
	@FXML
	public Button logoutButton;
	@FXML
	public Label authLabel;
	@FXML
	public Label totalLabel;
	@FXML
	public Label iPhoneLabel;
	@FXML
	public Label galaxyLabel;
	@FXML
	public Label pixelLabel;
	@FXML
	public Label pixelXLLabel;
	@FXML
	public Label onePlusLabel;
	
	public String iPhone;
	public String galaxy;
	public String pixel3;
	public String pixelXL;
	public String onePlus;
	public String total;
	public String authNum;
	
	public void getLabel() throws FileNotFoundException
	{
		File file = new File("C:/Users/Christian/eclipse-workspace/LoginSystem/src/DeliveryOrder.txt");
		File nameFile = new File("C:/Users/Christian/eclipse-workspace/LoginSystem/src/LoginSave.txt");
		Scanner scanner = new Scanner(file);
		Scanner nameScanner = new Scanner(nameFile);
		
		String userName = nameScanner.nextLine();
		
		while(scanner.hasNextLine())
		{
			String line = scanner.nextLine();
			if(Objects.equals(userName, line))
			{
				authNum = scanner.nextLine();
				total = scanner.nextLine();
				scanner.nextLine();
				iPhone = scanner.nextLine();
				scanner.nextLine();
				galaxy = scanner.nextLine();
				scanner.nextLine();
				pixel3 = scanner.nextLine();
				scanner.nextLine();
				pixelXL = scanner.nextLine();
				scanner.nextLine();
				onePlus = scanner.nextLine();
				scanner.close();
				break;
			}
		}
		nameScanner.close();
	}
	
	@FXML
	private void initialize() throws FileNotFoundException
	{
		getLabel();
		iPhoneLabel.setText(iPhone);
		galaxyLabel.setText(galaxy);
		pixelLabel.setText(pixel3);
		pixelXLLabel.setText(pixelXL);
		onePlusLabel.setText(onePlus);
		totalLabel.setText(total);
		authLabel.setText(authNum);
	}
	
	public void closeWindow() throws IOException
	{
		FileWriter fw = new FileWriter("C:/Users/Christian/eclipse-workspace/LoginSystem/src/LoginSave.txt",false);
		fw.write("");
		fw.close();
		Stage stage = (Stage) logoutButton.getScene().getWindow();
		stage.close();
	}
	
	public void okButton() throws IOException
	{
		okButton.getScene().getWindow().hide();
		main.showCustomerViewScene();
	}
}
