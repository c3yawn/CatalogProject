package UserLogin.view;

import java.io.FileWriter;
import java.io.IOException;

import UserLogin.LoginMain;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class SupplierViewMenuController {
	
	private LoginMain main;
	
	@FXML
	public Button logoutButton;
	@FXML
	public Button viewOrderButton;
	
	public void closeWindow() throws IOException
	{
		FileWriter fw = new FileWriter("C:/Users/Christian/eclipse-workspace/LoginSystem/src/LoginSave.txt",false);
		fw.write("");
		fw.close();
		Stage stage = (Stage) logoutButton.getScene().getWindow();
		stage.close();
	}

	public void goViewOrder() throws IOException
	{
		viewOrderButton.getScene().getWindow().hide();
		main.showSupplierViewOrderScene();
	}
	
}
