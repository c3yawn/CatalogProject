package UserLogin.view;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Objects;
import java.util.Scanner;

import UserLogin.LoginMain;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class CreateAccountController {
	
	ObservableList<String> userTypeList = FXCollections.observableArrayList("Customer", "Supplier");
	
	@FXML
	public ChoiceBox userTypeBox;
	@FXML 
	public Button closeButton;
	@FXML
	public Button cancelButton;
	@FXML
	private TextField userNameField;
	@FXML
	private PasswordField passwordField;
	@FXML
	private TextField nameField;
	@FXML
	private TextField phoneField;
	@FXML
	private TextField addressField;
	@FXML
	private TextField cardField;
	
	@FXML
	private void initialize()
	{
		userTypeBox.setValue("Customer");
		userTypeBox.setItems(userTypeList);
	}
	
	private void goNullFieldScene() throws IOException
	{
		LoginMain.showNullFieldScene();
	}
	
	@FXML
	private void storeUserInfo() throws IOException
	{
		String userName = userNameField.getText();
		String password = passwordField.getText();
		String name = nameField.getText();
		String phone = phoneField.getText();
		String address = addressField.getText();
		String card = cardField.getText();
		String userType = userTypeBox.getValue().toString();
		
		String fileName = null;
		
		if(Objects.equals(userType, "Customer"))
		{
			fileName = "C:/Users/Christian/eclipse-workspace/LoginSystem/src/UserInfo.txt";
		}
		else if(Objects.equals(userType, "Supplier"))
		{
			fileName = "C:/Users/Christian/eclipse-workspace/LoginSystem/src/SupplierLogin.txt";
		}
		
		File file = new File(fileName);
		Scanner scanner = new Scanner(file);
		boolean check = true;
		
		while(scanner.hasNextLine())
		{
			String line = scanner.nextLine();
			if(Objects.equals(userName, line))
			{
				LoginMain.showUserNameTakenScene();
				check = false;
				break;
			}
		}
		
		if(check)
		{
			if ((!userNameField.getText().isEmpty()) && (!passwordField.getText().isEmpty()) && (!nameField.getText().isEmpty() || Objects.equals(userType, "Supplier")) && (!phoneField.getText().isEmpty() || Objects.equals(userType, "Supplier")) && (!addressField.getText().isEmpty() || Objects.equals(userType, "Supplier")) && (!cardField.getText().isEmpty() || Objects.equals(userType, "Supplier")))
			{
				FileWriter fileWriter = new FileWriter(file, true);
				PrintWriter printWriter = new PrintWriter(fileWriter);
				
				printWriter.println(userName);
				printWriter.println(password);
				if(Objects.equals(userType, "Customer"))
				{
					printWriter.println(name);
					printWriter.println(phone);
					printWriter.println(address);
					printWriter.println(card);
				}
				printWriter.close();
				Stage stage = (Stage) closeButton.getScene().getWindow();
				stage.close();
			}
			else
			{
				goNullFieldScene();
			}
		}
	}
	
	@FXML
	public void closeWindow() throws IOException
	{
		Stage stage = (Stage) cancelButton.getScene().getWindow();
		stage.close();
	}
	
}