package UserLogin.view;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Objects;
import java.util.Random;
import java.util.Scanner;

import UserLogin.LoginMain;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class CatalogController {
	
	private LoginMain main;
	
	@FXML
	public Button checkoutButton;
	@FXML
	public Button logoutButton;
	@FXML
	public Button cancelButton;
	@FXML	
	public Label galaxyLabel;
	@FXML
	public Label pixel3Label;
	@FXML
	public Label pixelXLLabel;
	@FXML
	public Label onePlusLabel;
	@FXML
	public Button addiPhoneButton;
	@FXML
	public Button removeiPhoneButton;
	@FXML
	public Button addGalaxyButton;
	@FXML
	public Button removeGalaxyButton;
	@FXML
	public Button addPixel3Button;
	@FXML
	public Button removePixel3Button;
	@FXML
	public Button addPixelXLButton;
	@FXML
	public Button removePixelXLButton;
	@FXML
	public Button addOnePlusButton;
	@FXML
	public Button removeOnePlusButton;
	
	LoginMain login = new LoginMain();
	
	public int items[] = new int[5];
	public int itemCardinality;
	int orderIndex = 0;
	double total;
	
	@FXML
	private void addiPhone() throws IOException
	{
		items[0]++;
		total += 700.00;
	}
	
	@FXML
	private void removeiPhone() throws IOException
	{
		if(items[0] > 0)
		{
			items[0]--;
			total -= 700.00;
		}
	}
	
	@FXML
	private void addGalaxy() throws IOException
	{
		items[1]++;
		total += 999.99;
	}
	
	@FXML
	private void removeGalaxy() throws IOException
	{
		if(items[1] > 0)
		{
			items[1]--;
			total -= 999.99;
		}
	}
	
	@FXML
	private void addPixel3() throws IOException
	{
		items[2]++;
		total += 599.99;
	}
	
	@FXML
	private void removePixel3() throws IOException
	{
		if(items[2] > 0)
		{
			items[2]--;
			total -= 599.99;
		}
	}
	
	@FXML
	private void addPixelXL() throws IOException
	{
		items[3]++;
		total += 699.99;
	}
	
	@FXML
	private void removePixelXL() throws IOException
	{
		if(items[3] > 0)
		{
			items[3]--;
			total -= 699.99;
		}
	}
	
	@FXML
	private void addOnePlus() throws IOException
	{
		items[4]++;
		total += 599.99;
	}
	
	@FXML
	private void removeOnePlus() throws IOException
	{
		if(items[4] > 0)
		{
			items[4]--;
			total -= 599.99;
		}
	}
	
	@FXML
	private void checkout() throws IOException
	{
		UserLoginViewController usernameGet = new UserLoginViewController();
		String creditCard = null;
		int creditLimit = 0;
		
		File file = new File("C:/Users/Christian/eclipse-workspace/LoginSystem/src/UserInfo.txt");
		File file2 = new File("C:/Users/Christian/eclipse-workspace/LoginSystem/src/BankFile.txt");
		File nameFile = new File("C:/Users/Christian/eclipse-workspace/LoginSystem/src/LoginSave.txt");
		
		Scanner scanner = new Scanner(file);
		Scanner bankScanner = new Scanner(file2);
		Scanner nameScanner = new Scanner (nameFile);
		
		String userName = nameScanner.nextLine();
		
		while(scanner.hasNextLine())
		{
			String line = scanner.nextLine();
			System.out.println(line);
			if(Objects.equals(userName, line))
			{
				for(int i=5; i>0; i--)
				{
					creditCard = scanner.nextLine();
				}
				break;
			}
		}
		while(bankScanner.hasNextLine())
		{
			String line2 = bankScanner.nextLine();
			if(Objects.equals(creditCard, line2))
			{
				creditLimit = Integer.parseInt(bankScanner.nextLine());
				System.out.println(creditLimit);
				break;
			}
		}
		scanner.close();
		bankScanner.close();
		System.out.println(total);
		
		if(total>creditLimit)
		{
			main.showCreditLimitScene();
		}
		else
		{
			File orderFile = new File("C:/Users/Christian/eclipse-workspace/LoginSystem/src/DeliveryOrder.txt");
			
			FileWriter fileWriter = new FileWriter(orderFile, true);
			PrintWriter printWriter = new PrintWriter(fileWriter);
			
		    Random rnd = new Random();
		    int number = rnd.nextInt(999999);
		    String authNum = null;

		    authNum = String.format("%06d", number);
		    System.out.println(authNum);
		    printWriter.println(userName);
		    printWriter.println(authNum);
		    printWriter.println(total);
		    printWriter.println("iPhone X");
		    printWriter.println(items[0]);
		    printWriter.println("Galaxy S10+");
		    printWriter.println(items[1]);
		    printWriter.println("Pixel 3");
		    printWriter.println(items[2]);
		    printWriter.println("Pixel 3 XL");
		    printWriter.println(items[3]);
		    printWriter.println("OnePlus 6T");
		    printWriter.println(items[4]);
		    printWriter.close();
		    main.showCheckoutSuccessScene();
		    checkoutButton.getScene().getWindow().hide();
		}
	}
	
	public void closeWindow() throws IOException
	{
		FileWriter fw = new FileWriter("C:/Users/Christian/eclipse-workspace/LoginSystem/src/LoginSave.txt",false);
		fw.write("");
		fw.close();
		Stage stage = (Stage) logoutButton.getScene().getWindow();
		stage.close();
	}
	
	public void cancelButton() throws IOException
	{
		cancelButton.getScene().getWindow().hide();
		main.showCustomerViewScene();
	}
}
