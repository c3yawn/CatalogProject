package UserLogin.view;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import UserLogin.LoginMain;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class InventoryOrderController {
	
	private LoginMain main;
	
	@FXML
	public Button shipButton;
	@FXML
	public Label iPhoneLabel;
	@FXML
	public Label galaxyLabel;
	@FXML
	public Label pixelLabel;
	@FXML
	public Label pixelXLLabel;
	@FXML
	public Label onePlusLabel;
	
	@FXML
	private void initialize() throws FileNotFoundException
	{
		File file = new File("C:/Users/Christian/eclipse-workspace/LoginSystem/src/BooleanCheck.txt");
		Scanner scanner = new Scanner(file);
		
		scanner.nextLine();
		iPhoneLabel.setText(scanner.nextLine());
		scanner.nextLine();
		galaxyLabel.setText(scanner.nextLine());
		scanner.nextLine();
		pixelLabel.setText(scanner.nextLine());
		scanner.nextLine();
		pixelXLLabel.setText(scanner.nextLine());
		scanner.nextLine();
		onePlusLabel.setText(scanner.nextLine());
	}
	
	public void orderButton() throws IOException
	{
		pixelXLLabel.getScene().getWindow().hide();
		main.showFinalScene();
	}
}
