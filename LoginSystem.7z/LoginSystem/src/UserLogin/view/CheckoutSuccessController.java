package UserLogin.view;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Objects;
import java.util.Scanner;

import UserLogin.LoginMain;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class CheckoutSuccessController {

	
	
	@FXML
	public Label authLabel;
	
	private String getAuth() throws FileNotFoundException
	{
		File nameFile = new File("C:/Users/Christian/eclipse-workspace/LoginSystem/src/LoginSave.txt");
		Scanner nameScanner = new Scanner (nameFile);
		String userName = nameScanner.nextLine();
		
		File file = new File("C:/Users/Christian/eclipse-workspace/LoginSystem/src/DeliveryOrder.txt");
		Scanner scanner = new Scanner(file);
		
		String authNum = null;	
		
		while(scanner.hasNextLine())
		{
			String line = scanner.nextLine();
			if(Objects.equals(userName, line))
			{
				authNum = scanner.nextLine();
				break;
			}
		}
		
		return authNum;
	}
	
	@FXML
	private void initialize() throws FileNotFoundException
	{
		authLabel.setText("Authentication Number: " + getAuth());
	}
	
}
