package UserLogin;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;

public class LoginMain extends Application {
	private static Stage primaryStage;
	private static BorderPane mainLayout;
	
	@Override
	public void start(Stage primaryStage) throws IOException 
	{
		this.primaryStage = primaryStage;
		this.primaryStage.setTitle("User Login");
		showMainView();
	}
	
	private void showMainView() throws IOException
	{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(LoginMain.class.getResource("view/UserLoginView.fxml"));
		mainLayout = loader.load();
		Scene scene = new Scene(mainLayout);
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	public static void showCreateAccountScene() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(LoginMain.class.getResource("view/CreateAccount.fxml"));
		BorderPane createAccount = loader.load();

		Stage addDialogueStage = new Stage();
		addDialogueStage.setTitle("Create New Account");
		addDialogueStage.initModality(Modality.WINDOW_MODAL);
		addDialogueStage.initOwner(primaryStage);
		Scene scene = new Scene(createAccount);
		addDialogueStage.setScene(scene);
		addDialogueStage.showAndWait();
	}
	
	public static void showNullFieldScene() throws IOException
	{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(LoginMain.class.getResource("view/NullField.fxml"));
		BorderPane nullField = loader.load();
		Stage addDialogueStage = new Stage();
		addDialogueStage.setTitle("Incorrect Input");
		Scene scene = new Scene(nullField);
		addDialogueStage.setScene(scene);
		addDialogueStage.showAndWait();
	}
	
	public static void showUserNameTakenScene() throws IOException
	{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(LoginMain.class.getResource("view/UserNameTaken.fxml"));
		BorderPane usernameTaken = loader.load();
		Stage addDialogueStage = new Stage();
		addDialogueStage.setTitle("Username Already Taken");
		Scene scene = new Scene(usernameTaken);
		addDialogueStage.setScene(scene);
		addDialogueStage.showAndWait();
	}
	
	public static void showWrongPasswordScene() throws IOException
	{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(LoginMain.class.getResource("view/IncorrectPassword.fxml"));
		BorderPane wrongPassword = loader.load();
		Stage addDialogueStage = new Stage();
		addDialogueStage.setTitle("Incorrect Password");
		Scene scene = new Scene(wrongPassword);
		addDialogueStage.setScene(scene);
		addDialogueStage.showAndWait();
	}
	
	public static void showUsernameNotFoundScene() throws IOException
	{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(LoginMain.class.getResource("view/UsernameNotFound.fxml"));
		BorderPane usernameNotFound = loader.load();
		Stage addDialogueStage = new Stage();
		addDialogueStage.setTitle("Username Not Found");
		Scene scene = new Scene(usernameNotFound);
		addDialogueStage.setScene(scene);
		addDialogueStage.showAndWait();
	}
	
	public static void showWelcomeScene() throws IOException
	{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(LoginMain.class.getResource("view/Welcome.fxml"));
		BorderPane newLayout = loader.load();
		Stage newStage = new Stage();
		Scene newScene = new Scene(newLayout);
		newStage.setScene(newScene);
		newStage.setTitle("Welcome");
		newStage.show();
	}
	
	public static void showCustomerViewScene() throws IOException
	{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(LoginMain.class.getResource("view/CustomerViewMenu.fxml"));
		BorderPane newLayout = loader.load();
		Stage newStage = new Stage();
		Scene newScene = new Scene(newLayout);
		newStage.setScene(newScene);
		newStage.setTitle("View menu");
		newStage.show();
	}
	
	public static void showSupplierViewScene() throws IOException
	{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(LoginMain.class.getResource("view/SupplierViewMenu.fxml"));
		BorderPane newLayout = loader.load();
		Stage newStage = new Stage();
		Scene newScene = new Scene(newLayout);
		newStage.setScene(newScene);
		newStage.setTitle("View Menu");
		newStage.show();
	}
	
	public static void showCatalogScene() throws IOException
	{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(LoginMain.class.getResource("view/Catalog.fxml"));
		BorderPane newLayout = loader.load();
		Stage newStage = new Stage();
		Scene newScene = new Scene(newLayout);
		newStage.setScene(newScene);
		newStage.setTitle("Catalog");
		newStage.show();
	}
	
	public static void showCreditLimitScene() throws IOException
	{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(LoginMain.class.getResource("view/CreditLimit.fxml"));
		BorderPane newLayout = loader.load();
		Stage newStage = new Stage();
		Scene newScene = new Scene(newLayout);
		newStage.setScene(newScene);
		newStage.setTitle("Credit Limit Reached");
		newStage.show();
	}
	
	public static void showCheckoutSuccessScene() throws IOException
	{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(LoginMain.class.getResource("view/CheckoutSuccess.fxml"));
		BorderPane newLayout = loader.load();
		Stage newStage = new Stage();
		Scene newScene = new Scene(newLayout);
		newStage.setScene(newScene);
		newStage.setTitle("Catalog");
		newStage.show();
	}

	public static void showViewOrderScene() throws IOException
	{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(LoginMain.class.getResource("view/CustomerViewOrder.fxml"));
		BorderPane newLayout = loader.load();
		Stage newStage = new Stage();
		Scene newScene = new Scene(newLayout);
		newStage.setScene(newScene);
		newStage.setTitle("View Order");
		newStage.show();
	}
	
	public static void showSupplierViewOrderScene() throws IOException
	{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(LoginMain.class.getResource("view/SupplierViewOrder.fxml"));
		BorderPane newLayout = loader.load();
		Stage newStage = new Stage();
		Scene newScene = new Scene(newLayout);
		newStage.setScene(newScene);
		newStage.setTitle("View Orders");
		newStage.show();
	}
	
	public static void showOrderProcessScene() throws IOException
	{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(LoginMain.class.getResource("view/OrderProcess.fxml"));
		BorderPane newLayout = loader.load();
		Stage newStage = new Stage();
		Scene newScene = new Scene(newLayout);
		newStage.setScene(newScene);
		newStage.setTitle("Process Orders");
		newStage.show();
	}
	
	public static void showInventoryOrderScene() throws IOException
	{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(LoginMain.class.getResource("view/InventoryOrder.fxml"));
		BorderPane newLayout = loader.load();
		Stage newStage = new Stage();
		Scene newScene = new Scene(newLayout);
		newStage.setScene(newScene);
		newStage.setTitle("Order New Inventory");
		newStage.show();
	}
	
	public static void showFinalScene() throws IOException
	{
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(LoginMain.class.getResource("view/FinalScene.fxml"));
		BorderPane newLayout = loader.load();
		Stage newStage = new Stage();
		Scene newScene = new Scene(newLayout);
		newStage.setScene(newScene);
		newStage.setTitle("Orders Shipped");
		newStage.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
